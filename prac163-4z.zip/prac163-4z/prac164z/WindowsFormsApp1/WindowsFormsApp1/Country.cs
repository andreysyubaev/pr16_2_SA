﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Country
    {
        public string name { get; set; }
        public long population { get; set; }
    }
}
