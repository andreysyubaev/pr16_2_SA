﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            if (!File.Exists("countries.txt"))
            {
                MessageBox.Show("Файл со странами отсутствует");
                button1.Enabled = false;
            }
            else
            {
                string filePath = "countries.txt";
                StreamReader sr = new StreamReader(filePath);
                string content = sr.ReadToEnd();
                sr.Close();

                if (string.IsNullOrWhiteSpace(content))
                {
                    MessageBox.Show("Файл пуст.");
                    button1.Enabled = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string n = textBox1.Text;
            string filePath = "countries.txt";

            List<Country> countries = File.ReadAllLines(filePath)
                                          .Select(line => line.Split(' '))
                                          .Select(parts => new Country
                                          {
                                              name = string.Join(" ", parts.Take(parts.Length - 1)),
                                              population = int.Parse(parts.Last().Replace(" ", ""))
                                          }).ToList();

            int minPopulation;
            if (!int.TryParse(n, out minPopulation))
            {
                MessageBox.Show("Некорректный ввод, попробуйте снова.");
                return;
            }
            else
            {
                var filteredCountries = countries
                    .Where(country => country.population > minPopulation)
                    .OrderBy(country => country.name.Length)
                    .ThenBy(country => country.name)
                    .ToList();

                listBox1.Items.Clear();
                foreach (var country in filteredCountries)
                {
                    listBox1.Items.Add($"{country.name} {country.population:N0}");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
