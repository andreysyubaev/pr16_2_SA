﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] array = { 5.1, 1.3, 9.2, 2, 3, 5.1, 3 };

            // a)
            var freq = array.GroupBy(x => x)
                                 .Select(g => new { num = g.Key, count = g.Count() });

            Console.WriteLine("Число\tЧастота");
            Console.WriteLine("------------------------");
            foreach (var i in freq)
            {
                Console.WriteLine($"{i.num}\t{i.count}");
            }

            // b)
            var newArray = array.Select(x => x * freq.First(f => f.num == x).count).ToArray();

            Console.WriteLine("\nЧисло\tЧастота (старого массива)");
            Console.WriteLine("------------------------");
            foreach (var i in newArray)
            {
                Console.WriteLine(i);
            }
            Console.Read();
        }
    }
}
